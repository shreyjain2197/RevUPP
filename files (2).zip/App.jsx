import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import CategoryPage from './components/CategoryPage';
import ProductPage from './components/ProductPage';
import SurveyPage from './components/SurveyPage';
import CompletionPage from './components/CompletionPage';
import PointsCounter from './components/PointsCounter';
import './styles/global.css';

function App() {
  const [totalPoints, setTotalPoints] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [surveyAnswers, setSurveyAnswers] = useState({});
  const [answeredQuestions, setAnsweredQuestions] = useState(new Set());

  const awardPoints = (questionId, points) => {
    if (!answeredQuestions.has(questionId)) {
      setTotalPoints(prev => prev + points);
      setAnsweredQuestions(prev => new Set([...prev, questionId]));
    }
  };

  const saveAnswer = (questionId, answer) => {
    setSurveyAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  return (
    <div className="app">
      <PointsCounter points={totalPoints} />
      
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/category" element={<CategoryPage onSelectCategory={setSelectedCategory} />} />
        <Route path="/products" element={<ProductPage category={selectedCategory} onSelectProduct={setSelectedProduct} awardPoints={awardPoints} />} />
        <Route path="/survey" element={<SurveyPage product={selectedProduct} surveyAnswers={surveyAnswers} saveAnswer={saveAnswer} awardPoints={awardPoints} />} />
        <Route path="/completion" element={<CompletionPage totalPoints={totalPoints} surveyAnswers={surveyAnswers} product={selectedProduct} />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}

export default App;
