export const brandData = {
  name: 'Protein Pantry',
  logo: '/assets/protein-pantry-logo.png',
  revuLogo: '/assets/revu-logo.png',
  primaryColor: '#FF451B',
  secondaryColor: '#FFD93D',
  
  categories: [
    { id: 'snacks', name: 'Snacks', emoji: '🍿', description: 'Healthy protein-packed snacks' },
    { id: 'meals', name: 'Ready Meals', emoji: '🍱', description: 'Quick and nutritious meals' },
    { id: 'supplements', name: 'Supplements', emoji: '💊', description: 'Protein powders and bars' }
  ],
  
  products: {
    snacks: [
      { id: 'cheese-mushroom-cutlet', name: 'Cheese Mushroom Cutlet', emoji: '🧀', protein: '30G PROTEIN', category: 'snacks' },
      { id: 'chickpea-falafel', name: 'Chickpea Falafel', emoji: '🥙', protein: '26G PROTEIN', category: 'snacks' },
      { id: 'korean-bbq-chaap', name: 'Korean BBQ Chaap', emoji: '🍖', protein: '33G PROTEIN', category: 'snacks' }
    ],
    meals: [
      { id: 'tandoori-chaap', name: 'Tandoori Chaap', emoji: '🔥', protein: '38G PROTEIN', category: 'meals' },
      { id: 'sweet-potato-tikki', name: 'Sweet Potato Tikki', emoji: '🍠', protein: '26G PROTEIN', category: 'meals' },
      { id: 'beetroot-kebab', name: 'Beetroot Kebab', emoji: '🥗', protein: '27G PROTEIN', category: 'meals' }
    ],
    supplements: []
  },
  
  surveyQuestions: [
    {
      id: 'price',
      type: 'slider',
      question: 'How do you rate the price?',
      points: 2,
      config: { min: 0, max: 100, defaultValue: 50, leftLabel: 'Too Expensive', rightLabel: 'Great Value' }
    },
    {
      id: 'taste',
      type: 'emoji-mcq',
      question: 'How was the taste?',
      points: 2,
      config: {
        options: [
          { emoji: '😫', label: 'Bad', value: 1 },
          { emoji: '😐', label: 'Okay', value: 2 },
          { emoji: '😊', label: 'Good', value: 3 },
          { emoji: '😋', label: 'Great', value: 4 },
          { emoji: '🤩', label: 'Amazing', value: 5 }
        ]
      }
    },
    {
      id: 'packaging',
      type: 'mcq',
      question: 'What did you think of the packaging?',
      points: 2,
      config: { options: ['Easy to open', 'Eco-friendly', 'Attractive design', 'Needs improvement'] }
    },
    {
      id: 'quantity',
      type: 'slider',
      question: 'Was the quantity sufficient?',
      points: 2,
      config: { min: 0, max: 100, defaultValue: 50, leftLabel: 'Too Little', rightLabel: 'Perfect Amount' }
    },
    {
      id: 'ingredients',
      type: 'mcq',
      question: 'Do you trust the ingredients?',
      points: 2,
      config: { options: ['Yes, completely', 'Mostly yes', 'Neutral', 'Have concerns'] }
    },
    {
      id: 'digestion',
      type: 'mcq',
      question: 'How was digestion after eating?',
      points: 2,
      config: { options: ['Very easy', 'Normal', 'Slightly heavy', 'Uncomfortable'] }
    },
    {
      id: 'founder-message',
      type: 'text',
      question: 'Message to the founder',
      subtitle: 'If you could tell the founder one thing to improve, what would it be?',
      points: 5,
      config: { placeholder: 'Your suggestion here...', minLength: 10, isBonus: true }
    },
    {
      id: 'proof-upload',
      type: 'proof',
      question: 'Verify your purchase (Optional)',
      subtitle: 'Help us keep feedback genuine and earn bonus points!',
      points: 5,
      config: {
        options: [
          { icon: '📸', label: 'Product Photo', type: 'photo' },
          { icon: '🧾', label: 'Invoice/Bill', type: 'invoice' },
          { icon: '📱', label: 'Order Screenshot', type: 'screenshot' },
          { icon: '🤳', label: 'Selfie with Product', type: 'selfie' }
        ],
        isBonus: true,
        isOptional: true
      }
    }
  ],
  
  pointsRules: {
    perQuestion: 2,
    founderMessage: 5,
    proofUpload: 5,
    maxPossible: 22
  }
};

export default brandData;
