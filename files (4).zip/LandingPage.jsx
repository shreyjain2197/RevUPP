import React from 'react';
import { useNavigate } from 'react-router-dom';
import { brandData } from '../data/proteinPantryData';
import '../styles/LandingPage.css';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="landing-page">
      <div className="landing-container">
        <div className="landing-logo">
          <img src={brandData.logo} alt={brandData.name} />
        </div>

        <h1 className="landing-title">
          SHARE YOUR<br />
          <span className="highlight">FEEDBACK</span>
        </h1>

        <p className="landing-subtitle">
          Tell us about your experience and earn rewards!
        </p>

        <div className="landing-features">
          <div className="feature">
            <span className="feature-icon">⭐</span>
            <span className="feature-text">Earn points for every answer</span>
          </div>
          <div className="feature">
            <span className="feature-icon">🎁</span>
            <span className="feature-text">Get rewarded for honest feedback</span>
          </div>
          <div className="feature">
            <span className="feature-icon">⚡</span>
            <span className="feature-text">Takes only 2 minutes</span>
          </div>
        </div>

        <button className="btn btn-primary" onClick={() => navigate('/category')}>
          START SURVEY →
        </button>

        <div className="powered-by">
          <span>Powered by</span>
          <img src={brandData.revuLogo} alt="RevU" className="revu-logo" />
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
