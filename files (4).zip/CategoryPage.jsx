import React from 'react';
import { useNavigate } from 'react-router-dom';
import { brandData } from '../data/proteinPantryData';
import '../styles/CategoryPage.css';

function CategoryPage({ onSelectCategory }) {
  const navigate = useNavigate();

  const handleCategoryClick = (category) => {
    onSelectCategory(category);
    navigate('/products');
  };

  return (
    <div className="category-page">
      <div className="page-container">
        <h1 className="page-title">
          CHOOSE YOUR<br />
          <span className="highlight">CATEGORY</span>
        </h1>

        <p className="page-subtitle">
          What type of product did you try?
        </p>

        <div className="category-grid">
          {brandData.categories.map((category) => (
            <div
              key={category.id}
              className="category-card"
              onClick={() => handleCategoryClick(category)}
            >
              <div className="category-emoji">{category.emoji}</div>
              <h3 className="category-name">{category.name}</h3>
              <p className="category-description">{category.description}</p>
            </div>
          ))}
        </div>

        <button 
          className="btn btn-secondary" 
          onClick={() => navigate('/')}
        >
          ← BACK
        </button>
      </div>
    </div>
  );
}

export default CategoryPage;
