import React, { useState } from 'react';
import '../../styles/QuestionComponents.css';

/**
 * Emoji MCQ Component
 * Multiple choice with emoji options (e.g., taste rating)
 */
function EmojiMCQ({ question, currentAnswer, onSubmit }) {
  const [selectedValue, setSelectedValue] = useState(currentAnswer || null);

  const handleSelect = (option) => {
    setSelectedValue(option.value);
    // Auto-submit after selection (smoother UX)
    setTimeout(() => {
      onSubmit(option.value);
    }, 300);
  };

  return (
    <div className="question-container">
      <h2 className="question-title">{question.question}</h2>

      <div className="emoji-options">
        {question.config.options.map((option) => (
          <div
            key={option.value}
            className={`emoji-option ${selectedValue === option.value ? 'selected' : ''}`}
            onClick={() => handleSelect(option)}
          >
            <div className="emoji-icon">{option.emoji}</div>
            <div className="emoji-label">{option.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default EmojiMCQ;
