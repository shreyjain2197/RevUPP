import React, { useState } from 'react';
import '../../styles/QuestionComponents.css';

/**
 * Proof Upload Component
 * Simulates file upload for purchase verification
 * (Frontend-only - no actual backend upload)
 */
function ProofUpload({ question, currentAnswer, onSubmit, onSkip }) {
  const [selectedType, setSelectedType] = useState(currentAnswer?.type || null);
  const [uploadedFile, setUploadedFile] = useState(currentAnswer?.file || null);

  const handleTypeSelect = (type) => {
    setSelectedType(type);
  };

  // Simulate file upload
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedFile({
        name: file.name,
        size: file.size,
        type: file.type
      });
    }
  };

  const handleSubmit = () => {
    if (selectedType && uploadedFile) {
      onSubmit({
        type: selectedType,
        file: uploadedFile,
        timestamp: new Date().toISOString()
      });
    } else if (selectedType) {
      // User selected type but didn't upload - still give points for intent
      onSubmit({
        type: selectedType,
        intent: true
      });
    }
  };

  return (
    <div className="question-container">
      <h2 className="question-title">{question.question}</h2>
      
      {question.subtitle && (
        <p className="question-subtitle">{question.subtitle}</p>
      )}

      {question.config.isBonus && (
        <div className="bonus-badge">+{question.points} BONUS POINTS</div>
      )}

      <div className="proof-options">
        {question.config.options.map((option) => (
          <div
            key={option.type}
            className={`proof-option ${selectedType === option.type ? 'selected' : ''}`}
            onClick={() => handleTypeSelect(option.type)}
          >
            <div className="proof-icon">{option.icon}</div>
            <div className="proof-label">{option.label}</div>
          </div>
        ))}
      </div>

      {selectedType && (
        <div className="file-upload-section">
          <label className="file-upload-label">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="file-upload-input"
            />
            <span className="file-upload-button">
              {uploadedFile ? '✓ File Selected' : '📎 Choose File'}
            </span>
          </label>
          
          {uploadedFile && (
            <div className="file-upload-preview">
              <span className="file-name">{uploadedFile.name}</span>
              <button 
                className="file-remove"
                onClick={() => setUploadedFile(null)}
              >
                ✕
              </button>
            </div>
          )}
        </div>
      )}

      <div className="proof-actions">
        <button 
          className="btn btn-primary" 
          onClick={handleSubmit}
          disabled={!selectedType}
        >
          SUBMIT →
        </button>
        
        <button 
          className="btn btn-ghost" 
          onClick={onSkip}
        >
          Skip (Optional)
        </button>
      </div>

      <p className="proof-note">
        <small>Your data is secure and used only for verification purposes.</small>
      </p>
    </div>
  );
}

export default ProofUpload;
