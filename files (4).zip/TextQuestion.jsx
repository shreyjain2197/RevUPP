import React, { useState } from 'react';
import '../../styles/QuestionComponents.css';

/**
 * Text Question Component
 * For open-ended text responses (e.g., founder message)
 */
function TextQuestion({ question, currentAnswer, onSubmit }) {
  const [text, setText] = useState(currentAnswer || '');

  const handleSubmit = () => {
    if (text.trim().length >= (question.config.minLength || 0)) {
      onSubmit(text);
    }
  };

  const isValid = text.trim().length >= (question.config.minLength || 0);
  const charCount = text.length;

  return (
    <div className="question-container">
      <h2 className="question-title">{question.question}</h2>
      
      {question.subtitle && (
        <p className="question-subtitle">{question.subtitle}</p>
      )}

      {question.config.isBonus && (
        <div className="bonus-badge">+{question.points} BONUS POINTS</div>
      )}

      <div className="text-input-container">
        <textarea
          className="text-input"
          placeholder={question.config.placeholder}
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={5}
        />
        
        <div className="text-input-footer">
          <span className="char-count">
            {charCount} characters
            {question.config.minLength && ` (min ${question.config.minLength})`}
          </span>
        </div>
      </div>

      <button 
        className="btn btn-primary btn-submit" 
        onClick={handleSubmit}
        disabled={!isValid}
      >
        NEXT →
      </button>
    </div>
  );
}

export default TextQuestion;
