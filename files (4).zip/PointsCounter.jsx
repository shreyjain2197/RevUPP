import React from 'react';
import '../styles/PointsCounter.css';

function PointsCounter({ points }) {
  return (
    <div className="points-counter">
      <span className="points-icon">⭐</span>
      <span className="points-value">{points}</span>
      <span className="points-label">POINTS</span>
    </div>
  );
}

export default PointsCounter;
