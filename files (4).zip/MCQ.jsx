import React, { useState } from 'react';
import '../../styles/QuestionComponents.css';

/**
 * MCQ Component
 * Standard multiple choice question (e.g., packaging, ingredients)
 */
function MCQ({ question, currentAnswer, onSubmit }) {
  const [selectedOption, setSelectedOption] = useState(currentAnswer || null);

  const handleSelect = (option) => {
    setSelectedOption(option);
  };

  const handleSubmit = () => {
    if (selectedOption) {
      onSubmit(selectedOption);
    }
  };

  return (
    <div className="question-container">
      <h2 className="question-title">{question.question}</h2>

      <div className="mcq-options">
        {question.config.options.map((option, index) => (
          <div
            key={index}
            className={`mcq-option ${selectedOption === option ? 'selected' : ''}`}
            onClick={() => handleSelect(option)}
          >
            <div className="mcq-radio">
              {selectedOption === option && <div className="mcq-radio-fill" />}
            </div>
            <span className="mcq-text">{option}</span>
          </div>
        ))}
      </div>

      <button 
        className="btn btn-primary btn-submit" 
        onClick={handleSubmit}
        disabled={!selectedOption}
      >
        NEXT →
      </button>
    </div>
  );
}

export default MCQ;
