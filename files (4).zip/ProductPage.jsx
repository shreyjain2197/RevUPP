import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { brandData } from '../data/proteinPantryData';
import '../styles/ProductPage.css';

function ProductPage({ category, onSelectProduct, awardPoints }) {
  const navigate = useNavigate();
  const [selectedProductId, setSelectedProductId] = useState(null);

  const products = category ? brandData.products[category.id] || [] : [];

  const handleProductClick = (product) => {
    setSelectedProductId(product.id);
    onSelectProduct(product);
    awardPoints('product-selection', 2);
  };

  const handleContinue = () => {
    if (selectedProductId) {
      navigate('/survey');
    }
  };

  return (
    <div className="product-page">
      <div className="page-container">
        <h1 className="page-title">
          PICK YOUR<br />
          <span className="highlight">PROTEIN!</span>
        </h1>

        <p className="page-subtitle">
          Which {category?.name.toLowerCase()} did you try?
        </p>

        <div className="product-grid">
          {products.map((product) => (
            <div
              key={product.id}
              className={`product-card ${selectedProductId === product.id ? 'selected' : ''}`}
              onClick={() => handleProductClick(product)}
            >
              <div className="product-emoji">{product.emoji}</div>
              <h3 className="product-name">{product.name}</h3>
              <p className="product-protein">{product.protein}</p>
            </div>
          ))}
        </div>

        <div className="button-group">
          <button 
            className="btn btn-secondary" 
            onClick={() => navigate('/category')}
          >
            ← BACK
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleContinue}
            disabled={!selectedProductId}
          >
            CONTINUE →
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductPage;
