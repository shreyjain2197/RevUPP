import React from 'react';
import { useNavigate } from 'react-router-dom';
import { brandData } from '../data/proteinPantryData';
import '../styles/CompletionPage.css';

function CompletionPage({ totalPoints, surveyAnswers, product }) {
  const navigate = useNavigate();

  const questionPoints = Object.keys(surveyAnswers).filter(
    key => !key.includes('founder') && !key.includes('proof') && !key.includes('product')
  ).length * brandData.pointsRules.perQuestion;

  const founderPoints = surveyAnswers['founder-message'] ? brandData.pointsRules.founderMessage : 0;
  const proofPoints = surveyAnswers['proof-upload'] ? brandData.pointsRules.proofUpload : 0;

  const handleNewSurvey = () => {
    window.location.href = '/';
  };

  return (
    <div className="completion-page">
      <div className="completion-container">
        <div className="completion-icon">🎉</div>

        <h1 className="completion-title">THANK YOU!</h1>

        <p className="completion-message">
          Your feedback helps shape future products
        </p>

        <div className="points-summary">
          <div className="points-header">TOTAL POINTS EARNED</div>
          <div className="points-total">{totalPoints}</div>

          <div className="points-breakdown">
            <div className="breakdown-row">
              <span>Questions Answered:</span>
              <strong>+{questionPoints}</strong>
            </div>
            {founderPoints > 0 && (
              <div className="breakdown-row">
                <span>Founder Message:</span>
                <strong>+{founderPoints}</strong>
              </div>
            )}
            {proofPoints > 0 && (
              <div className="breakdown-row">
                <span>Purchase Verified:</span>
                <strong>+{proofPoints}</strong>
              </div>
            )}
          </div>
        </div>

        <div className="reward-message">
          <p><strong>More points = higher chances of rewards!</strong></p>
          <p className="reward-subtitle">
            We'll notify you when you're eligible for exclusive offers
          </p>
        </div>

        <div className="reviewed-product">
          <span className="reviewed-label">You reviewed:</span>
          <div className="reviewed-product-card">
            <span className="reviewed-emoji">{product?.emoji}</span>
            <span className="reviewed-name">{product?.name}</span>
          </div>
        </div>

        <div className="completion-actions">
          <button className="btn btn-primary" onClick={handleNewSurvey}>
            REVIEW ANOTHER PRODUCT
          </button>
        </div>

        <div className="powered-by">
          <span>Powered by</span>
          <img src={brandData.revuLogo} alt="RevU" className="revu-logo" />
        </div>
      </div>
    </div>
  );
}

export default CompletionPage;
