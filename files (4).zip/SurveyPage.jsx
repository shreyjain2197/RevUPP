import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { brandData } from '../data/proteinPantryData';
import SliderQuestion from './QuestionComponents/SliderQuestion';
import EmojiMCQ from './QuestionComponents/EmojiMCQ';
import MCQ from './QuestionComponents/MCQ';
import TextQuestion from './QuestionComponents/TextQuestion';
import ProofUpload from './QuestionComponents/ProofUpload';
import '../styles/SurveyPage.css';

function SurveyPage({ product, surveyAnswers, saveAnswer, awardPoints }) {
  const navigate = useNavigate();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const currentQuestion = brandData.surveyQuestions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === brandData.surveyQuestions.length - 1;
  const progress = ((currentQuestionIndex + 1) / brandData.surveyQuestions.length) * 100;

  const handleAnswerSubmit = (answer) => {
    saveAnswer(currentQuestion.id, answer);
    
    if (answer && answer !== '' && answer !== null) {
      awardPoints(currentQuestion.id, currentQuestion.points);
    }

    if (isLastQuestion) {
      navigate('/completion');
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handleSkip = () => {
    if (isLastQuestion) {
      navigate('/completion');
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    } else {
      navigate('/products');
    }
  };

  const renderQuestion = () => {
    const commonProps = {
      question: currentQuestion,
      currentAnswer: surveyAnswers[currentQuestion.id],
      onSubmit: handleAnswerSubmit,
      onSkip: handleSkip,
    };

    switch (currentQuestion.type) {
      case 'slider':
        return <SliderQuestion {...commonProps} />;
      case 'emoji-mcq':
        return <EmojiMCQ {...commonProps} />;
      case 'mcq':
        return <MCQ {...commonProps} />;
      case 'text':
        return <TextQuestion {...commonProps} />;
      case 'proof':
        return <ProofUpload {...commonProps} />;
      default:
        return <div>Unknown question type</div>;
    }
  };

  return (
    <div className="survey-page">
      <div className="survey-progress">
        <div className="progress-bar-container">
          <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
        </div>
        <div className="progress-text">
          Question {currentQuestionIndex + 1} of {brandData.surveyQuestions.length}
        </div>
      </div>

      <div className="survey-product-context">
        <span className="product-emoji-small">{product?.emoji}</span>
        <span className="product-name-small">{product?.name}</span>
      </div>

      <div className="survey-container">
        {renderQuestion()}
      </div>

      <div className="survey-navigation">
        <button className="btn btn-ghost" onClick={handleBack}>
          ← Back
        </button>
        
        {currentQuestion.config?.isOptional && (
          <button className="btn btn-ghost" onClick={handleSkip}>
            Skip →
          </button>
        )}
      </div>
    </div>
  );
}

export default SurveyPage;
