import React, { useState, useEffect } from 'react';
import '../../styles/QuestionComponents.css';

/**
 * Slider Question Component
 * Renders a slider input for range-based questions (e.g., price, quantity)
 */
function SliderQuestion({ question, currentAnswer, onSubmit }) {
  const [value, setValue] = useState(currentAnswer || question.config.defaultValue);

  useEffect(() => {
    if (currentAnswer !== undefined) {
      setValue(currentAnswer);
    }
  }, [currentAnswer]);

  const handleSubmit = () => {
    onSubmit(value);
  };

  return (
    <div className="question-container">
      <h2 className="question-title">{question.question}</h2>
      
      {question.config.isBonus && (
        <div className="bonus-badge">+{question.points} BONUS POINTS</div>
      )}

      <div className="slider-container">
        <div className="slider-labels">
          <span className="slider-label-left">{question.config.leftLabel}</span>
          <span className="slider-label-right">{question.config.rightLabel}</span>
        </div>

        <div className="slider-track">
          <div 
            className="slider-fill" 
            style={{ width: `${value}%` }}
          />
          <input
            type="range"
            min={question.config.min}
            max={question.config.max}
            value={value}
            onChange={(e) => setValue(Number(e.target.value))}
            className="slider-input"
          />
        </div>

        <div className="slider-value">{value}%</div>
      </div>

      <button 
        className="btn btn-primary btn-submit" 
        onClick={handleSubmit}
      >
        NEXT →
      </button>
    </div>
  );
}

export default SliderQuestion;
